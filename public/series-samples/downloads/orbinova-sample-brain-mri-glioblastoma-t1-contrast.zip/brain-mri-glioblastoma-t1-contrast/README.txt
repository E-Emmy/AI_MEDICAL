Orbinova Imaging - public sample scans for the Full scan (3D) feature
Downloaded 2026-11-13 from The Cancer Imaging Archive (TCIA), https://www.cancerimagingarchive.net

1. brain-mri-glioblastoma-t1-contrast/
   Brain MRI, T1 with contrast, axial. 192 slices, 256 x 192, 1 mm slices. Uncompressed DICOM.
   Patient UPENN-GBM-00002, who has a glioblastoma (brain tumour). It is clearly visible on the middle slices.
   Collection: UPENN-GBM. Licence: CC BY 4.0.
   Credit: Bakas S. et al., "Multi-parametric magnetic resonance imaging (mpMRI) scans for de novo
   Glioblastoma (GBM) patients from the University of Pennsylvania Health System (UPENN-GBM)",
   The Cancer Imaging Archive, 2021. https://doi.org/10.7937/TCIA.709X-DN49

2. chest-ct-lung-nodule/
   Chest CT. 133 slices, 512 x 512, 2.5 mm slices. Uncompressed DICOM.
   Patient LIDC-IDRI-0001, who has a lung nodule marked by radiologists.
   Collection: LIDC-IDRI. Licence: CC BY 3.0.
   Credit: Armato SG III et al., "The Lung Image Database Consortium (LIDC) and Image Database Resource
   Initiative (IDRI)", The Cancer Imaging Archive, 2015. https://doi.org/10.7937/K9/TCIA.2015.LO9QL9SX

Rules from TCIA's data usage policy (see the LICENSE file in each folder):
- Credit the collections above when you show them (for example on a slide or in the app's sample list).
- Never try to identify the patients, and do not make images that could reveal who they are.
  The brain MRI still includes the face, so the 3D view must not show a rendered face or skin surface.
